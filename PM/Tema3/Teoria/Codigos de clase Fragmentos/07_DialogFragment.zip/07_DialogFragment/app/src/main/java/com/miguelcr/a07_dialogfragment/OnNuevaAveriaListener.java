package com.miguelcr.a07_dialogfragment;

/**
 * Created by miguelcampos on 27/10/17.
 */

public interface OnNuevaAveriaListener {
    public void onAveriaGuardarClickListener();
}
