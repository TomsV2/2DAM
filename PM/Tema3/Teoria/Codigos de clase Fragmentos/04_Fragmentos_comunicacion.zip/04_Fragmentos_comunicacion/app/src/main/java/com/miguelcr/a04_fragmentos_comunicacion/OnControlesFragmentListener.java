package com.miguelcr.a04_fragmentos_comunicacion;

/**
 * Created by miguelcampos on 26/10/17.
 */

public interface OnControlesFragmentListener {
    public void botonColorClicked(String color);
    public void botonTextoClicked(String texto);
    public void mensaje(String texto);
}
